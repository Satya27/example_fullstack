<script>
  import { onMount } from "svelte";

  let menus = [];
  let newMenu = { menu: "", harga: "", diskon: "", stok: "" };
  let editMenu = null;

  async function fetchMenus() {
    try {
      const response = await fetch("http://127.0.0.1:8000/menu/");
      menus = await response.json();
    } catch (error) {
      console.error("Error fetching menus:", error);
    }
  }

  async function addMenu() {
    try {
      const response = await fetch("http://127.0.0.1:8000/menu/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newMenu),
      });
      const result = await response.json();
      console.log(result);
      fetchMenus();
      newMenu = { menu: "", harga: "", diskon: "", stok: "" };
    } catch (error) {
      console.error("Error adding menu:", error);
    }
  }

  async function updateMenu() {
    try {
      const response = await fetch(
        `http://127.0.0.1:8000/menu/${editMenu.id_menu}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(editMenu),
        }
      );
      const result = await response.json();
      console.log(result);
      fetchMenus();
      editMenu = null;
    } catch (error) {
      console.error("Error updating menu:", error);
    }
  }

  async function deleteMenu(id) {
    try {
      const response = await fetch(`http://127.0.0.1:8000/menu/${id}`, {
        method: "DELETE",
      });
      const result = await response.json();
      console.log(result);
      fetchMenus();
    } catch (error) {
      console.error("Error deleting menu:", error);
    }
  }

  function setEditMenu(menu) {
    editMenu = { ...menu };
  }

  onMount(() => {
    fetchMenus();
  });
</script>

<div class="container">
  {#if editMenu}
    <h2>Edit Menu</h2>
    <form on:submit|preventDefault={updateMenu}>
      <input type="text" bind:value={editMenu.menu} placeholder="Menu" />
      <input type="number" bind:value={editMenu.harga} placeholder="Harga" />
      <input type="number" bind:value={editMenu.diskon} placeholder="Diskon" />
      <input type="number" bind:value={editMenu.stok} placeholder="Stok" />
      <button type="submit">Update Menu</button>
      <button type="button" on:click={() => (editMenu = null)}>Cancel</button>
    </form>
  {:else}
    <h2>Add Menu</h2>
    <form on:submit|preventDefault={addMenu}>
      <input type="text" bind:value={newMenu.menu} placeholder="Menu" />
      <input type="number" bind:value={newMenu.harga} placeholder="Harga" />
      <input type="number" bind:value={newMenu.diskon} placeholder="Diskon" />
      <input type="number" bind:value={newMenu.stok} placeholder="Stok" />
      <button type="submit">Add Menu</button>
    </form>
  {/if}

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Menu</th>
        <th>Harga</th>
        <th>Diskon</th>
        <th>Stok</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {#each menus as menu}
        <tr>
          <td>{menu.id_menu}</td>
          <td>{menu.menu}</td>
          <td>{menu.harga}</td>
          <td>{menu.diskon}</td>
          <td>{menu.stok}</td>
          <td class="actions">
            <button on:click={() => setEditMenu(menu)}>Edit</button>
            <button on:click={() => deleteMenu(menu.id_menu)}>Delete</button>
          </td>
        </tr>
      {/each}
    </tbody>
  </table>
</div>

<style>
  .container {
    background-color: #444;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 800px;
    width: 100%;
  }

  tbody {
    color: #fff;
  }

  h2 {
    color: #ff9800;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 20px;
  }

  input,
  button {
    padding: 10px;
    border: none;
    border-radius: 4px;
  }

  input {
    background-color: #555;
    color: #fff;
  }

  button {
    background-color: #ff9800;
    color: #fff;
    cursor: pointer;
  }

  button:hover {
    background-color: #e68900;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
  }

  th,
  td {
    padding: 10px;
    text-align: left;
  }

  th {
    background-color: #555;
  }

  tr:nth-child(even) {
    background-color: #444;
  }

  tr:nth-child(odd) {
    background-color: #555;
  }

  .actions button {
    margin-right: 10px;
  }
</style>
