from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, HTTPException
from mysql.connector import Error
import mysql.connector


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)


def connect():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            database="db_kasir",
            username="root",
            password=""
        )
        if conn.is_connected():
            return conn
    except Error as e:
        print("Error connected to Database")
        return None


@app.get("/menu/")
async def lihat_menu():
    conn = connect()
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM t_menu ORDER BY id_menu DESC")
        results = cursor.fetchall()
        if not results:
            raise HTTPException(status_code=404, detail="Data menu not found")
        return results
    else:
        raise HTTPException(
            status_code=500, detail="Failed to connect to database")


@app.get("/menu/{id_menu}")
async def lihat_menu(id_menu: int):
    conn = connect()
    if conn:
        cursor = conn.cursor(dictionary=True)
        query = "SELECT * FROM t_menu WHERE id_menu = %s"
        cursor.execute(query, (id_menu,))
        result = cursor.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Menu not found")
        return result
    else:
        raise HTTPException(
            status_code=500, detail="Failed to connect to database")


@app.post("/menu/")
async def tambah_menu(in_data: dict):
    if not isinstance(in_data, dict):
        raise HTTPException(
            status_code=400, detail="Input should be a valid dictionary")

    conn = connect()
    if conn:
        cursor = conn.cursor()
        query = "INSERT INTO t_menu(menu, harga, diskon, stok) VALUES (%s, %s, %s, %s)"
        values = (in_data.get('menu'), in_data.get('harga'),
                  in_data.get('diskon'), in_data.get('stok'))
        cursor.execute(query, values)
        conn.commit()
        return {"info": "Berhasil Input", "status": "1"}
    else:
        raise HTTPException(
            status_code=500, detail="Failed to connect to database")


@app.put("/menu/{id_menu}")
async def ubah_menu(id_menu: int, up_data: dict):
    conn = connect()
    if conn:
        cursor = conn.cursor()
        query = "UPDATE t_menu SET menu = %s, harga = %s, diskon = %s, stok = %s WHERE id_menu = %s"
        values = (up_data.get('menu'), up_data.get('harga'), up_data.get('diskon'),
                  up_data.get('stok'), id_menu)
        cursor.execute(query, values)
        conn.commit()
        return {"info": "Berhasil Update", "status": "1"}
    else:
        raise HTTPException(
            status_code=500, detail="Failed to connect to database")


@app.delete("/menu/{id_menu}")
async def del_menu(id_menu: int):
    conn = connect()  # Panggil fungsi connect untuk membuat koneksi
    if conn:
        cursor = conn.cursor()
        query = "DELETE FROM t_menu WHERE id_menu=%s"
        cursor.execute(query, (id_menu,))  # Sertakan nilai dalam bentuk tupel
        conn.commit()  # Ganti conn.comit() dengan conn.commit()
        return {"info": "Berhasil Hapus", "status": "1"}
    else:
        raise HTTPException(
            status_code=500, detail="Failed to connect to database")
